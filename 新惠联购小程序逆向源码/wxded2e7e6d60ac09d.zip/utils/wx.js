var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Wx = void 0;

var r = e(require("../@babel/runtime/regenerator")), t = require("../@babel/runtime/helpers/asyncToGenerator"), n = require("../@babel/runtime/helpers/classCallCheck"), u = require("../@babel/runtime/helpers/createClass"), a = e(require("./util")), s = function() {
    function e() {
        n(this, e);
    }
    var s, i, c, l;
    return u(e, null, [ {
        key: "wxLogin",
        value: (l = t(r.default.mark(function e() {
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, a.default.promisic(wx.login)();

                  case 2:
                    return e.abrupt("return", e.sent);

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, e);
        })), function() {
            return l.apply(this, arguments);
        })
    }, {
        key: "wxRequestPayment",
        value: (c = t(r.default.mark(function e(t) {
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.prev = 0, e.next = 3, a.default.promisic(wx.requestPayment)(t);

                  case 3:
                    return e.abrupt("return", e.sent);

                  case 6:
                    return e.prev = 6, e.t0 = e.catch(0), e.abrupt("return", e.t0);

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, e, null, [ [ 0, 6 ] ]);
        })), function(e) {
            return c.apply(this, arguments);
        })
    }, {
        key: "wxGetSetting",
        value: (i = t(r.default.mark(function e() {
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, a.default.promisic(wx.getSetting)();

                  case 2:
                    return e.abrupt("return", e.sent);

                  case 3:
                  case "end":
                    return e.stop();
                }
            }, e);
        })), function() {
            return i.apply(this, arguments);
        })
    }, {
        key: "wxGetUserInfo",
        value: (s = t(r.default.mark(function e() {
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, this.wxGetSetting();

                  case 2:
                    if (!e.sent.authSetting["scope.userInfo"]) {
                        e.next = 9;
                        break;
                    }
                    return e.next = 6, a.default.promisic(wx.getUserInfo)();

                  case 6:
                    return e.abrupt("return", e.sent);

                  case 9:
                    return e.abrupt("return", null);

                  case 10:
                  case "end":
                    return e.stop();
                }
            }, e, this);
        })), function() {
            return s.apply(this, arguments);
        })
    } ]), e;
}();

exports.Wx = s;