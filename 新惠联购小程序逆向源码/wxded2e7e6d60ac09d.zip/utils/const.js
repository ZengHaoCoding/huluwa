Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.LOGIN_AGREEMENTS = exports.GROUP_LOGIN_AGREEMENTS = void 0;

exports.LOGIN_AGREEMENTS = [ {
    name: "用户协议",
    isRead: !1,
    isPdf: !1,
    url: "https://hqmall.huiqunchina.com/pages/agreement/userAgreement-wujiang.html"
}, {
    name: "隐私协议",
    isRead: !1,
    isPdf: !1,
    url: "https://hqmall.huiqunchina.com/pages/agreement/privacy-wujiang.html"
} ];

exports.GROUP_LOGIN_AGREEMENTS = [ {
    name: "用户协议",
    isRead: !1,
    isPdf: !1,
    url: "https://hqmall.huiqunchina.com/pages/agreement/groupUserAgreement-wujiang.html"
}, {
    name: "隐私协议",
    isRead: !1,
    isPdf: !1,
    url: "https://hqmall.huiqunchina.com/pages/agreement/groupPrivacy-wujiang.html"
} ];