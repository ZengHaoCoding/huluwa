var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = require("../@babel/runtime/helpers/typeof"), n = e(require("./config.js")), r = function(e) {
    return (e = e.toString())[1] ? e : "0" + e;
}, i = {
    getParams: function(e) {
        var t = {};
        if (!e) return "";
        var n = e.indexOf("?");
        if (-1 === n) return t;
        if (!(e = e.substr(n + 1))) return t;
        for (var r, i, a, o = e.split("&"), u = 0; u < o.length; u++) -1 !== (r = o[u].indexOf("=")) && (i = o[u].substring(0, r), 
        a = o[u].substring(r + 1), a = decodeURIComponent(a), t[i] ? t[i] += "," + a : t[i] = a);
        return t;
    },
    setParam: function(e, n, r) {
        if ("object" === t(n)) {
            for (var i in r = e, n) r = this.setParam(i, n[i], r);
            return r;
        }
        r || (r = "");
        var a = r.split("#");
        if (a.length > 1 && (r = a[0]), r.indexOf("?") > -1) {
            var o, u, l = r.split("?");
            if (-1 === r.indexOf(e)) return r + "&" + e + "=" + n;
            if (o = l[0], 1 === (u = l[1].split("&")).length && !u[0]) return o + "?" + e + "=" + n;
            for (var s = 0; s < u.length; s++) if (u[s].indexOf(e + "=") > -1) {
                u.splice(s, 1);
                break;
            }
            n && u.push(e + "=" + n), r = o + "?" + u.join("&");
        } else r = r + "?" + e + "=" + n;
        return a.length > 1 ? r + "#" + a[1] : r;
    }
}, a = {
    formatTime: function(e) {
        var t = e.getFullYear(), n = e.getMonth() + 1, i = e.getDate(), a = e.getHours(), o = e.getMinutes(), u = e.getSeconds();
        return [ t, n, i ].map(r).join("/") + " " + [ a, o, u ].map(r).join(":");
    },
    webviewUrl: n.default.webviewUrl,
    getMsg: function(e, t) {
        return t ? e && e.detail && t(e.detail.data[0]) : e && e.detail && e.detail.data[0];
    },
    promisic: function(e) {
        return function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            return new Promise(function(n, r) {
                var i = Object.assign(t, {
                    success: function(e) {
                        n(e);
                    },
                    fail: function(e) {
                        r(e);
                    }
                });
                e(i);
            });
        };
    },
    buildUrl: function(e, t) {
        var r, i = arguments.length > 2 && void 0 !== arguments[2] && arguments[2], a = wx.getStorageSync("accessToken") || "";
        if (t) r = t.split("#"); else {
            if (!n.default.webviewUrl[e]) return wx.showModal({
                content: e + "页面不存在"
            });
            r = n.default.webviewUrl[e].split("#");
        }
        var o = r[0], u = "slientToken=".concat(encodeURIComponent(a));
        return t && (e.env = "miniapp", e && Object.keys(e).forEach(function(t) {
            o.indexOf("?") > -1 ? o += "&".concat(t, "=").concat(e[t]) : o += "?".concat(t, "=").concat(e[t]);
        }), o = n.default.domain + o), i && (o += "&_minId_=".concat(parseInt(1e4 * Math.random()))), 
        r.length > 1 && r[1].indexOf("?") > -1 ? o += "#" + r[1] + "&" + u : o += "#" + r[1] + "?" + u, 
        o;
    },
    urlTools: i
};

exports.default = a;