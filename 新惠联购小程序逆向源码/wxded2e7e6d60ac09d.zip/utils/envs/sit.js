Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    api: "https://gw-sit.huiqunchina.com",
    domain: "https://hqmall-sit.huiqunchina.com",
    isDev: !0,
    ak: "2619895f5a6c996f5ed3f47a7f914e92",
    sk: "8b2e7521b68c869c962b08f75610978a",
    encryption: !0
};