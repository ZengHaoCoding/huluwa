Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    api: "https://gw.huiqunchina.com",
    domain: "https://hqmall.huiqunchina.com",
    ak: "1608466d96bddacb530a8fa9a9428d14",
    sk: "2e95d1a0b3ac14d5cf01b106314443bb",
    encryption: !0
};