Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    api: "https://gw-uat.huiqunchina.com",
    domain: "https://hqmall-uat.huiqunchina.com",
    isDev: !0,
    ak: "fc89f5954599422de702918f8074831e",
    sk: "4255b7546a23a0a127ca002b10c5518d",
    encryption: !0
};