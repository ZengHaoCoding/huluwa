Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

exports.default = {
    api: "https://gw-daily.huiqunchina.com",
    domain: "https://hqmall-daily.huiqunchina.com",
    isDev: !0,
    ak: "376a86bde963c112015a978e28e8961c",
    sk: "afd19405ced5979f68c1e7e5a9c1c617",
    encryption: !0
};