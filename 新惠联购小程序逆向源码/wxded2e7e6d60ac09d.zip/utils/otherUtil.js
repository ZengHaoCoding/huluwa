function e(e) {
    try {
        var r = [];
        for (var t in e) {
            var o = encodeURIComponent(t), a = encodeURIComponent(e[t]);
            r.push(o + "=" + a);
        }
        return r.join("&");
    } catch (e) {
        e = VM2_INTERNAL_STATE_DO_NOT_USE_OR_PROGRAM_WILL_FAIL.handleException(e);
        return "";
    }
}

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, exports.parseParams = e;

var r = {
    parseParams: e
};

exports.default = r;