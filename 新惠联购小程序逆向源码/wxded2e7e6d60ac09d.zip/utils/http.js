var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.Http = void 0, require("../@babel/runtime/helpers/Arrayincludes");

var r = e(require("../@babel/runtime/regenerator")), t = require("../@babel/runtime/helpers/objectSpread2"), a = require("../@babel/runtime/helpers/typeof"), n = require("../@babel/runtime/helpers/asyncToGenerator"), i = require("../@babel/runtime/helpers/classCallCheck"), o = require("../@babel/runtime/helpers/createClass"), u = e(require("./util")), s = e(require("./config")), c = require("./encryption"), l = (require("./encryption2"), 
[ "checkToken", "silenceLogin", "miniAppLogin" ]), p = function() {
    function e() {
        i(this, e);
    }
    var p;
    return o(e, null, [ {
        key: "request",
        value: (p = n(r.default.mark(function e(n) {
            var i, o, p, d, b, f, h, m, q, y, g, v, k, x, w, T, j, S, C;
            return r.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return i = n.url, o = n.data, p = n.headers, d = void 0 === p ? {} : p, b = n.method, 
                    f = void 0 === b ? "POST" : b, h = n.isEncryption, m = void 0 === h || h, q = n.prefix, 
                    y = void 0 === q ? "/front-manager" : q, g = n.noMsg, v = void 0 !== g && g, k = wx.getStorageSync("accessToken") || "", 
                    x = Object.assign({
                        "content-type": "application/json"
                    }, d), k && !l.includes(i) && (x["X-access-token"] = k), "object" === a(o) && (o = JSON.stringify(o)), 
                    w = "".concat(s.default.api).concat(i), s.default.encryption && m && (w = "".concat(s.default.api).concat(y).concat(i), 
                    T = c.encryptionData, x = t(t({}, x), T({
                        method: f,
                        url: "".concat(y).concat(i),
                        body: o,
                        ak: s.default.ak,
                        sk: s.default.sk
                    }))), e.next = 9, u.default.promisic(wx.request)({
                        header: x,
                        url: w,
                        data: o,
                        method: f
                    });

                  case 9:
                    if (200 === (j = e.sent).statusCode) {
                        e.next = 14;
                        break;
                    }
                    return wx.showToast({
                        title: "网络异常,请稍后重试",
                        duration: 2500,
                        icon: "error"
                    }), e.abrupt("return", !1);

                  case 14:
                    return S = j.data.code, C = j.data.message ? j.data.message : "", "10000" !== S && C && (console.log("err:: ", j.data), 
                    v || wx.showToast({
                        title: C,
                        icon: "error"
                    })), e.abrupt("return", j.data);

                  case 18:
                  case "end":
                    return e.stop();
                }
            }, e);
        })), function(e) {
            return p.apply(this, arguments);
        })
    } ]), e;
}();

exports.Http = p;