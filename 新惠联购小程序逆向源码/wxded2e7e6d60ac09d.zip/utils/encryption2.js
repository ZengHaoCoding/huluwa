var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.encryptionData2 = function() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, r = e.ak, a = e.sk, u = e.method, i = e.url, o = e.body, s = t({
        method: u,
        url: i,
        ak: r,
        sk: a
    }), l = n(o, a), c = {
        "X-HMAC-SIGNATURE": s,
        "X-HMAC-ACCESS-KEY": r,
        "X-HMAC-ALGORITHM": "hmac-sha256",
        "X-HMAC-DIGEST": l
    };
    return c;
};

var r = e(require("crypto-js"));

function t() {
    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, t = e.method, n = e.url, a = e.ak, u = e.sk, i = t + "\n" + n + "\n\n" + a + "\n\n", o = r.default.HmacSHA256(i, u);
    return o = r.default.enc.Base64.stringify(o);
}

function n(e, t) {
    var n = r.default.HmacSHA256(e, t);
    return n = r.default.enc.Base64.stringify(n);
}