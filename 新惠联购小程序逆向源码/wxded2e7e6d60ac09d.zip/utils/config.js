var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0;

var t = e(require("../@babel/runtime/regenerator")), i = require("../@babel/runtime/helpers/asyncToGenerator"), r = require("./otherUtil"), s = e(require("./envs/daily")), a = e(require("./envs/uat")), n = e(require("./envs/sit")), l = e(require("./envs/prod")), o = {
    env: "",
    api: "",
    domain: "",
    isDev: !1,
    webviewUrl: {},
    appId: "wxded2e7e6d60ac09d",
    code: "",
    openId: "",
    channelId: "",
    isGetDatas: !1,
    encryption: !1,
    ak: "",
    sk: "",
    loginType: "1",
    userType: "1",
    custType: 4,
    init: function(e) {
        var r = this;
        return i(t.default.mark(function i() {
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    r.env = e, r.setEvnData(e), r.setWebviewUrl();

                  case 3:
                  case "end":
                    return t.stop();
                }
            }, i);
        }))();
    },
    setEvnData: function(e) {
        var t = this, i = l.default;
        "trial" == e && (i = n.default), "develop" == e && (i = s.default), "uat" == e && (i = a.default), 
        "sit" == e && (i = n.default), "daily" == e && (i = s.default), Object.keys(i).forEach(function(e) {
            t[e] = i[e];
        });
    },
    setWebviewUrl: function() {
        var e = (0, r.parseParams)({
            env: "miniapp",
            appId: this.appId,
            openId: this.openId,
            channelId: this.channelId,
            projectEnv: this.env,
            loginType: this.loginType,
            userType: this.userType,
            custType: this.custType
        }), t = "".concat(this.domain, "/pages/shop.html?").concat(e, "#"), i = "".concat(this.domain, "/pages/shop_base.html?").concat(e, "#");
        this.webviewUrl.home = t + "/home", this.webviewUrl.category = t + "/category", 
        this.webviewUrl.integral = t + "/integral", this.webviewUrl.detail = t + "/detail", 
        this.webviewUrl.bridge = t + "/bridge", this.webviewUrl.member = t + "/member", 
        this.webviewUrl.search = t + "/search", this.webviewUrl.shopcart = t + "/shopcart", 
        this.webviewUrl.faxian = t + "/discover", this.webviewUrl.shophome = t + "/shophome", 
        this.webviewUrl.tickets = t + "/tickets", this.webviewUrl.login = i + "/login", 
        this.webviewUrl.identity = i + "/identity", this.webviewUrl.orderDetail = i + "/orderDetail", 
        this.webviewUrl.orderList = i + "/orderList";
    }
};

exports.default = o;