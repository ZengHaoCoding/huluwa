var e = require("../@babel/runtime/helpers/interopRequireDefault");

Object.defineProperty(exports, "__esModule", {
    value: !0
}), exports.default = void 0, exports.getActivity = function() {
    return p.apply(this, arguments);
}, exports.getChannelId = c, exports.getDatas = l, exports.getUserInfo = u;

var t = e(require("../@babel/runtime/regenerator")), r = require("../@babel/runtime/helpers/asyncToGenerator"), a = require("./http"), n = e(require("./config"));

function u() {
    return s.apply(this, arguments);
}

function s() {
    return (s = r(t.default.mark(function e() {
        var r, u, s;
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, a.Http.request({
                    url: "/api/customer/queryById/token",
                    data: {
                        channel: "h5"
                    }
                });

              case 2:
                (r = e.sent).success && (u = r.data, (s = u.custType) || (s = 4), n.default.custType = s, 
                4 == s ? (n.default.loginType = 1, n.default.userType = 1, n.default.openId = r.data.openId, 
                r.data.isRealNameAuth || wx.redirectTo({
                    url: "/pages/identity/identity"
                })) : (n.default.loginType = 2, n.default.userType = 2));

              case 4:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function c() {
    return i.apply(this, arguments);
}

function i() {
    return (i = r(t.default.mark(function e() {
        var r, u;
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return n.default.channelId = wx.getStorageSync("channelId"), e.next = 3, a.Http.request({
                    url: "/api/get/channelId",
                    data: {
                        appId: n.default.appId
                    }
                });

              case 3:
                return (r = e.sent).success && (r.serverTimeStamp && (u = r.serverTimeStamp - new Date().getTime(), 
                wx.setStorageSync("serverBetweenTime", String(u))), n.default.channelId = r.data, 
                wx.setStorageSync("channelId", r.data)), e.abrupt("return", n.default.channelId);

              case 6:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function p() {
    return (p = r(t.default.mark(function e() {
        var r;
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return e.next = 2, a.Http.request({
                    url: "/api/customer/promotion/channelActivity",
                    data: {
                        id: n.default.channelId
                    }
                });

              case 2:
                (r = e.sent).success && (n.default.activityId = r.data.id);

              case 4:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

function l() {
    return d.apply(this, arguments);
}

function d() {
    return (d = r(t.default.mark(function e() {
        var r = arguments;
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return r.length > 0 && void 0 !== r[0] ? r[0] : {}, e.next = 3, c();

              case 3:
                return wx.getStorageSync("accessToken"), e.next = 6, u();

              case 6:
                n.default.setWebviewUrl(), n.default.isGetDatas = !0, console.log("config参数", n.default);

              case 9:
              case "end":
                return e.stop();
            }
        }, e);
    }))).apply(this, arguments);
}

var o = {
    getDatas: l
};

exports.default = o;