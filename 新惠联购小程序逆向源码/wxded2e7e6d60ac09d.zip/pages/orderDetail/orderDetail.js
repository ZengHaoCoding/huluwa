var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../utils/util")), r = require("../../utils/otherUtil");

Page({
    data: {
        url: "",
        orderId: ""
    },
    onLoad: function(t) {
        wx.hideHomeButton({}), this.setData({
            orderId: t.orderId
        });
        var a = (0, r.parseParams)({
            orderId: t.orderId
        }), i = e.default.buildUrl("orderDetail") + "&" + a;
        this.setData({
            url: i
        });
    },
    onShareAppMessage: function(e) {}
});