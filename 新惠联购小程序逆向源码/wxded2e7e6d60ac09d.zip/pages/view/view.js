var n = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../utils/util"));

Page({
    data: {},
    onLoad: function(o) {
        var e = "";
        o.url && (e = decodeURIComponent(o.url)), e = n.default.buildUrl({}, e), this.setData({
            url: e
        });
    },
    onLoadFinish: function() {
        wx.hideLoading();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});