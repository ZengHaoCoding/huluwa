var n = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../utils/util"));

Page({
    data: {},
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {
        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, o = e.id, t = (e.spm, 
        n.default.buildUrl("shophome") + "&id=" + o);
        this.setData({
            url: t
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});