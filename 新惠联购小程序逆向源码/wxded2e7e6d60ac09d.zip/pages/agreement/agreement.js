Page({
    data: {
        url: ""
    },
    onLoad: function(t) {
        this.setData({
            url: t.url
        });
    }
});