var e, r = require("../../@babel/runtime/helpers/interopRequireDefault"), t = r(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator"), a = r(require("../../utils/util"));

Page({
    data: {
        url: ""
    },
    onLoad: function(e) {
        wx.showLoading({
            title: "加载中"
        });
    },
    onShow: (e = n(t.default.mark(function e() {
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                this.setData({
                    url: a.default.buildUrl("shopcart", "", !0)
                });

              case 1:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function() {
        return e.apply(this, arguments);
    }),
    onLoadCompelete: function() {
        wx.hideLoading();
    },
    onShareAppMessage: function(e) {}
});