var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), i = require("../../@babel/runtime/helpers/asyncToGenerator"), n = e(require("../../utils/util")), r = (require("../../utils/http"), 
require("../../utils/wx")), a = require("../../utils/otherUtil"), u = getApp();

Page({
    data: {
        url: "",
        phone: "",
        isNew: 0
    },
    onLoad: function(e) {
        var t, i, n, r, a = this;
        this.setData({
            isNew: null !== (t = null == u || null === (i = u.globalData) || void 0 === i ? void 0 : i.isNew) && void 0 !== t ? t : 0
        });
        var o = null !== (n = null == u || null === (r = u.globalData) || void 0 === r ? void 0 : r.loginPhone) && void 0 !== n ? n : null;
        o && this.setData({
            phone: o
        });
        var l = setTimeout(function() {
            clearTimeout(l), a.init(e);
        }, 100);
        setInterval(function() {
            a.init(e);
        }, 24e4);
    },
    onShow: function() {},
    init: function(e) {
        var u = this;
        return i(t.default.mark(function i() {
            var o, l, s, d, c;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    return o = (e || {
                        edit: 0
                    }).edit, wx.hideHomeButton({}), t.next = 4, r.Wx.wxLogin();

                  case 4:
                    return l = t.sent, t.next = 7, r.Wx.wxLogin();

                  case 7:
                    s = t.sent, d = (0, a.parseParams)({
                        code: l.code,
                        code2: s.code,
                        phone: u.data.phone,
                        isNew: Number(u.data.isNew),
                        isEdit: o
                    }), c = n.default.buildUrl("identity") + "&" + d, console.log(c, 222222), u.setData({
                        url: c
                    });

                  case 12:
                  case "end":
                    return t.stop();
                }
            }, i);
        }))();
    },
    onShareAppMessage: function(e) {}
});