var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../@babel/runtime/regenerator")), t = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../utils/wx"), r = require("../../utils/otherUtil");

Page({
    data: {
        isNet: !1,
        money: "",
        orderId: "",
        title: "",
        subtitle: "",
        payData: {
            timeStamp: "",
            nonceStr: "",
            package: "",
            signType: "",
            paySign: ""
        }
    },
    onLoad: function(e) {
        if (console.log("options", e), wx.hideHomeButton({}), "MOCK" === e.payData) return this.setData({
            money: e.money,
            orderId: e.orderId,
            title: decodeURIComponent(e.title),
            subtitle: decodeURIComponent(e.subtitle),
            topTitle: decodeURIComponent(e.topTitle),
            payData: {}
        }), void this.toSuccessPage();
        var t = JSON.parse(decodeURIComponent(e.payData));
        this.setData({
            money: e.money,
            orderId: e.orderId,
            title: decodeURIComponent(e.title),
            subtitle: decodeURIComponent(e.subtitle),
            topTitle: decodeURIComponent(e.topTitle),
            payData: {
                timeStamp: t.timeStamp.toString(),
                nonceStr: t.nonceStr,
                package: t.package,
                signType: t.signType,
                paySign: t.paySign
            }
        });
    },
    toSuccessPage: function() {
        var e = (0, r.parseParams)({
            orderId: this.data.orderId,
            topTitle: this.data.topTitle,
            title: this.data.title,
            subtitle: this.data.subtitle
        });
        wx.redirectTo({
            url: "/pages/myPaySuccess/myPaySuccess?".concat(e)
        });
    },
    toFailurePage: function() {
        var e = (0, r.parseParams)({
            orderId: this.data.orderId,
            topTitle: this.data.topTitle
        });
        wx.redirectTo({
            url: "/pages/myPayFailure/myPayFailure?".concat(e)
        });
    },
    toPay: function() {
        var r = this;
        return t(e.default.mark(function t() {
            var o, i, n;
            return e.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (o = r.data, i = o.payData, !o.isNet) {
                        e.next = 3;
                        break;
                    }
                    return e.abrupt("return");

                  case 3:
                    return r.setData({
                        isNet: !0
                    }), e.next = 6, a.Wx.wxRequestPayment(i).catch(function() {
                        r.setData({
                            isNet: !1
                        });
                    });

                  case 6:
                    n = e.sent, r.setData({
                        isNet: !1
                    }), "requestPayment:ok" === (null == n ? void 0 : n.errMsg) ? r.toSuccessPage() : r.toFailurePage();

                  case 9:
                  case "end":
                    return e.stop();
                }
            }, t);
        }))();
    },
    onShareAppMessage: function(e) {}
});