var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../utils/util"));

Page({
    data: {
        url: ""
    },
    onLoad: function(n) {
        var a = n.link;
        a = decodeURIComponent(a);
        var t = e.default.buildUrl({
            breadcrumb: 3
        }, a, !0);
        console.log(t);
        var i = !1;
        [ "/integral", "/payment" ].forEach(function(e) {
            -1 != t.indexOf(e) && (i = !0);
        }), this.setData({
            link: a,
            url: t,
            isReset: i
        });
    },
    onLoadFinish: function() {
        wx.hideLoading();
    },
    onReady: function() {},
    onShow: function() {
        if (this.data.isReset) {
            var n = e.default.buildUrl({
                breadcrumb: 3
            }, this.data.link, !0);
            this.setData({
                url: n
            });
        }
    },
    onHide: function() {},
    webViewMessage: function(n) {
        e.default.getMsg(n, function(e) {
            if (console.log(e), "share" === e.action) {
                var n = e.shareData;
                n.shareUrl, n.shareTitle, n.shareDesc;
            }
        });
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});