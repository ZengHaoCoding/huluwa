var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../utils/util"));

Page({
    data: {
        url: "",
        link: "",
        isReset: !1
    },
    onLoad: function(n) {
        var t = n.link;
        t = decodeURIComponent(t);
        var o = e.default.buildUrl({
            breadcrumb: 1
        }, t, !0);
        console.log(o);
        var a = !1;
        [ "/integral", "/payment" ].forEach(function(e) {
            -1 != o.indexOf(e) && (a = !0);
        }), this.setData({
            link: t,
            url: o,
            isReset: a
        });
    },
    onLoadFinish: function() {
        wx.hideLoading();
    },
    onReady: function() {},
    onShow: function() {
        if (this.data.isReset) {
            var n = e.default.buildUrl({
                breadcrumb: 1
            }, this.data.link, !0);
            this.setData({
                url: n
            });
        }
    },
    onHide: function() {},
    webViewMessage: function(n) {
        console.log("------aaaaa------"), e.default.getMsg(n, function(e) {
            if (console.log(e), "share" === e.action) {
                var n = e.shareData;
                n.shareUrl, n.shareTitle, n.shareDesc;
            }
        });
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function(e) {
        console.log(e), console.log("tttttt");
    }
});