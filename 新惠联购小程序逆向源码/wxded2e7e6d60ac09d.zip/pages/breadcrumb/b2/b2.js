var e = require("../../../@babel/runtime/helpers/interopRequireDefault")(require("../../../utils/util"));

Page({
    data: {
        url: "",
        link: "",
        isReset: !1
    },
    onLoad: function(n) {
        var i = n.link;
        i = decodeURIComponent(i);
        var t = e.default.buildUrl({
            breadcrumb: 2
        }, i, !0), a = !1;
        [ "/integral", "/payment" ].forEach(function(e) {
            -1 != t.indexOf(e) && (a = !0);
        }), this.setData({
            link: i,
            url: t,
            isReset: a
        });
    },
    onLoadFinish: function() {
        wx.hideLoading();
    },
    onReady: function() {},
    onShow: function() {
        if (this.data.isReset) {
            var n = e.default.buildUrl({
                breadcrumb: 2
            }, this.data.link, !0);
            this.setData({
                url: n
            });
        }
    },
    onHide: function() {},
    webViewMessage: function(n) {
        e.default.getMsg(n, function(e) {
            if (console.log(e), "share" === e.action) {
                var n = e.shareData;
                n.shareUrl, n.shareTitle, n.shareDesc;
            }
        });
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});