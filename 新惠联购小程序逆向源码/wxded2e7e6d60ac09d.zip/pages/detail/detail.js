var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../utils/util"));

Page({
    data: {
        url: "",
        messages: []
    },
    onLoad: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, a = t.id, i = t.spm, n = e.default.buildUrl("detail") + "&id=" + a;
        i && (n += "&spm=" + i), this.setData({
            url: n
        });
    },
    onShow: function() {},
    onReady: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function(e) {
        for (var t = this.data.messages, a = 0; a < t.length; a++) {
            var i = t[a];
            if ("setShareOption" === i.type) return {
                title: i.title,
                path: i.path,
                imageUrl: i.imageUrl
            };
        }
    },
    detailMessage: function(e) {
        var t = e.detail;
        this.setData({
            messages: t.data
        });
    }
});