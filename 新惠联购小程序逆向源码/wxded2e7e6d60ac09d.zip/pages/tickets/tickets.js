var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../utils/util")), t = require("../../utils/otherUtil");

Page({
    data: {
        url: "",
        routerParams: {}
    },
    onLoad: function(e) {
        this.setData({
            routerParams: e
        });
    },
    onShow: function() {
        var r = (this.data.routerParams || {}).isNohome, a = void 0 === r ? 0 : r;
        wx.hideHomeButton({}), getCurrentPages().length > 1 && wx.reLaunch({
            url: "/pages/tickets/tickets"
        });
        var i = (0, t.parseParams)({
            isNohome: a
        }), s = e.default.buildUrl("tickets") + "&" + i;
        this.setData({
            url: s
        });
    },
    onShareAppMessage: function(e) {}
});