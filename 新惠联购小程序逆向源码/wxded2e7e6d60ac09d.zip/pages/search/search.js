var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../utils/util"));

Page({
    data: {
        url: ""
    },
    onLoad: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {}, n = "", i = "";
        if (t.url) {
            var o = (n = decodeURIComponent(t.url)).split("?")[1];
            if (o) {
                for (var r = o.split("&"), a = 0; a < r.length; a++) {
                    var l = r[a].split("=");
                    if ("title" === l[0]) {
                        i = l[1];
                        break;
                    }
                }
                i && wx.setNavigationBarTitle({
                    title: i
                });
            }
        }
        n = e.default.buildUrl("search", n), this.setData({
            url: n
        });
    },
    onReady: function() {},
    onShow: function(e) {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});