var n = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../utils/util"));

Page({
    data: {},
    onLoad: function(n) {},
    onReady: function() {},
    onShow: function() {
        var e = n.default.buildUrl("articleDetail");
        this.setData({
            url: e
        });
    },
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});