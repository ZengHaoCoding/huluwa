var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../utils/util"));

Page({
    data: {
        url: ""
    },
    onLoad: function(e) {
        wx.showLoading({
            title: "加载中"
        });
    },
    onShow: function() {
        this.setData({
            url: e.default.buildUrl("member", "", !0)
        });
    },
    onPullDownRefresh: function() {
        wx.stopPullDownRefresh();
    },
    onLoadCompelete: function() {
        wx.hideLoading();
    },
    onShareAppMessage: function(e) {}
});