var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator"), i = require("../../utils/http"), o = require("../../utils/wx"), a = e(require("../../utils/config")), r = require("../../utils/common");

Page({
    onLoad: function(e) {
        console.log(e, 22222), "logout" == e.type && this.logout(e), "login" == e.type && this.login(e), 
        "wxLogin" == e.type && this.wxLogin(e), "goxijiu" == e.type && this.goxijiu(e);
    },
    logout: function(e) {
        wx.removeStorageSync("accessToken"), wx.reLaunch({
            url: "/pages/login/login"
        });
    },
    login: function(e) {
        wx.removeStorageSync("accessToken"), wx.setStorageSync("accessToken", e.token), 
        setTimeout(function() {
            wx.switchTab({
                url: "/pages/home/home"
            });
        }, 100);
    },
    wxLogin: function(e) {
        var c = this;
        return n(t.default.mark(function e() {
            var n, s, u;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    return e.next = 2, o.Wx.wxLogin();

                  case 2:
                    return n = e.sent, s = {
                        code: n.code,
                        appId: a.default.appId
                    }, e.next = 6, i.Http.request({
                        url: "/api/login/wxMiniLogin",
                        data: s
                    });

                  case 6:
                    if (!(u = e.sent).success) {
                        e.next = 12;
                        break;
                    }
                    return wx.setStorageSync("accessToken", u.data.token), e.next = 11, (0, r.getDatas)();

                  case 11:
                    c.gotoHome();

                  case 12:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    gotoHome: function() {
        setTimeout(function() {
            wx.redirectTo({
                url: "/pages/tickets/tickets"
            });
        }, 100);
    },
    goxijiu: function(e) {
        wx.showModal({
            title: "即将打开其他小程序",
            content: "",
            success: function(e) {
                if (e.confirm) {
                    wx.navigateToMiniProgram({
                        appId: "wx950babf936508e51",
                        path: "/packAgeF/pages/wineActivity/wineActivity",
                        extraData: {
                            token: "xxxxxxxxxx"
                        },
                        envVersion: "release",
                        success: function(e) {},
                        fail: function(e) {
                            wx.navigateBack();
                        }
                    });
                } else e.cancel && wx.navigateBack();
            }
        });
    }
});