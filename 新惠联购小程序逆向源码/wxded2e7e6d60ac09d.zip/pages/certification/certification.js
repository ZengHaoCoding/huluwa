Page({
    data: {
        url: ""
    },
    onLoad: function(t) {
        var a = decodeURIComponent(t.url);
        this.setData({
            url: a
        });
    }
});