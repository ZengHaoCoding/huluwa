Component({
    properties: {
        tabList: {
            type: Array,
            value: []
        },
        value: {
            type: String,
            value: "1"
        },
        onChange: {
            type: Function,
            value: function() {}
        }
    },
    methods: {
        change: function(e) {
            var t = e.currentTarget.dataset.value;
            this.triggerEvent("onChange", {
                value: t
            });
        }
    }
});