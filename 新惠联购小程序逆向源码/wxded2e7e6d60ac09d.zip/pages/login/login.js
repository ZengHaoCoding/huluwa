var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../@babel/runtime/regenerator")), n = require("../../@babel/runtime/helpers/asyncToGenerator"), a = require("../../utils/const"), r = require("../../utils/http"), o = require("../../utils/wx"), s = e(require("../../utils/config")), u = require("../../utils/common"), i = null, c = getApp();

Page({
    data: {
        phone: "",
        securityCode: "",
        agree: !1,
        agreements: a.LOGIN_AGREEMENTS,
        hasSendCode: !1,
        timeOut: 60,
        disabled: !1,
        showButtons: !0,
        tabVal: "1",
        tabList: [ {
            title: "零售用户登录",
            value: "1"
        }, {
            title: "规模用户登录",
            value: "2"
        } ],
        groupType: "1",
        account: "",
        password: "",
        logoNum: 0
    },
    onLaunch: function() {
        clearTimeout(i);
    },
    onLoad: function() {
        this.onHandover();
    },
    logoClick: function() {},
    onHandover: function() {
        var e = this.data.tabVal;
        this.setData({
            agreements: 1 == +e ? a.LOGIN_AGREEMENTS : a.GROUP_LOGIN_AGREEMENTS
        });
    },
    onChange: function(e) {
        this.setData({
            tabVal: e.detail.value,
            phone: "",
            securityCode: ""
        }), this.onHandover();
    },
    onShow: function() {
        var e;
        clearTimeout(i), wx.hideHomeButton({}), getCurrentPages().length > 1 && wx.reLaunch({
            url: "/pages/login/login"
        });
        var t = wx.getAccountInfoSync(), n = null == t || null === (e = t.miniProgram) || void 0 === e ? void 0 : e.envVersion;
        this.setData({
            env: n
        }), this.initCountDown();
    },
    onHide: function() {
        clearTimeout(i);
    },
    phoneLogin: function(e) {
        var a = this;
        return n(t.default.mark(function e() {
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    (function() {
                        var e = n(t.default.mark(function e() {
                            var n, i, c, d, l, h, p;
                            return t.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (n = a.data, i = n.phone, c = n.securityCode, d = n.agree, i) {
                                        e.next = 3;
                                        break;
                                    }
                                    return e.abrupt("return", wx.showToast({
                                        title: "请输入手机号码",
                                        icon: "error",
                                        duration: 2e3
                                    }));

                                  case 3:
                                    if (new RegExp(/^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/).test(a.data.phone)) {
                                        e.next = 8;
                                        break;
                                    }
                                    return wx.showToast({
                                        title: "手机号码不正确",
                                        icon: "error",
                                        duration: 2e3
                                    }), e.abrupt("return");

                                  case 8:
                                    if (c) {
                                        e.next = 10;
                                        break;
                                    }
                                    return e.abrupt("return", wx.showToast({
                                        title: "请输入验证码",
                                        icon: "error",
                                        duration: 2e3
                                    }));

                                  case 10:
                                    if (d) {
                                        e.next = 12;
                                        break;
                                    }
                                    return e.abrupt("return", wx.showToast({
                                        title: "请阅读并勾选协议",
                                        icon: "error"
                                    }));

                                  case 12:
                                    return e.next = 14, o.Wx.wxLogin();

                                  case 14:
                                    return l = e.sent, h = {
                                        phone: i,
                                        securityCode: c,
                                        appId: s.default.appId,
                                        code: l.code
                                    }, wx.showLoading({
                                        title: "加载中"
                                    }), e.next = 19, r.Http.request({
                                        url: "/api/login/phoneLogin",
                                        data: h
                                    });

                                  case 19:
                                    if ((p = e.sent).success) {
                                        e.next = 23;
                                        break;
                                    }
                                    return wx.showToast({
                                        title: p.message,
                                        duration: 2e3,
                                        mask: !0,
                                        icon: "error"
                                    }), e.abrupt("return");

                                  case 23:
                                    if (!p.success) {
                                        e.next = 32;
                                        break;
                                    }
                                    if (!p.data.isNeedRegister) {
                                        e.next = 27;
                                        break;
                                    }
                                    return a.goRealNameAuth(!0, p.data), e.abrupt("return");

                                  case 27:
                                    return wx.removeStorageSync("accessToken"), wx.setStorageSync("accessToken", p.data.token), 
                                    e.next = 31, (0, u.getDatas)();

                                  case 31:
                                    a.gotoHome();

                                  case 32:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }));
                        return function() {
                            return e.apply(this, arguments);
                        };
                    })()();

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    toHome: function() {
        wx.switchTab({
            url: "/pages/home/home"
        });
    },
    preGetPhoneNumber: function(e) {
        var a = this;
        return n(t.default.mark(function e() {
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    (function() {
                        var e = n(t.default.mark(function e() {
                            var n, i, c;
                            return t.default.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                  case 0:
                                    if (a.data.agree) {
                                        e.next = 3;
                                        break;
                                    }
                                    return wx.showToast({
                                        title: "请阅读并勾选协议",
                                        icon: "error"
                                    }), e.abrupt("return");

                                  case 3:
                                    return e.next = 5, o.Wx.wxLogin();

                                  case 5:
                                    return n = e.sent, console.log(n), i = {
                                        appId: s.default.appId,
                                        code: n.code
                                    }, wx.showLoading({
                                        title: "加载中"
                                    }), e.next = 11, r.Http.request({
                                        url: "/api/login/wxMiniLogin",
                                        data: i
                                    });

                                  case 11:
                                    if (!(c = e.sent).success) {
                                        e.next = 20;
                                        break;
                                    }
                                    if (!c.data.isNeedRegister) {
                                        e.next = 16;
                                        break;
                                    }
                                    return a.goRealNameAuth(!1, c.data), e.abrupt("return");

                                  case 16:
                                    return wx.setStorageSync("accessToken", c.data.token), e.next = 19, (0, u.getDatas)();

                                  case 19:
                                    a.gotoHome();

                                  case 20:
                                  case "end":
                                    return e.stop();
                                }
                            }, e);
                        }));
                        return function() {
                            return e.apply(this, arguments);
                        };
                    })()();

                  case 2:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    groupLogin: function(e) {
        var a = this;
        return n(t.default.mark(function e() {
            var n, i, c, d, l, h, p;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n = a.data, i = n.account, c = n.password, a.data.agree) {
                        e.next = 4;
                        break;
                    }
                    return wx.showToast({
                        title: "请阅读并勾选协议",
                        icon: "error"
                    }), e.abrupt("return");

                  case 4:
                    if (i) {
                        e.next = 7;
                        break;
                    }
                    return wx.showToast({
                        title: "请输入账号",
                        icon: "error",
                        duration: 2e3
                    }), e.abrupt("return");

                  case 7:
                    if (c) {
                        e.next = 10;
                        break;
                    }
                    return wx.showToast({
                        title: "请输入密码",
                        icon: "error",
                        duration: 2e3
                    }), e.abrupt("return");

                  case 10:
                    return e.next = 12, (0, u.getChannelId)();

                  case 12:
                    return d = e.sent, e.next = 15, o.Wx.wxLogin();

                  case 15:
                    return l = e.sent, h = {
                        type: 1,
                        idNo: i,
                        password: c,
                        channelId: d,
                        code: l.code,
                        appId: s.default.appId
                    }, e.next = 19, r.Http.request({
                        url: "/api/login/cardPwd",
                        data: h
                    });

                  case 19:
                    if (!(p = e.sent).success) {
                        e.next = 25;
                        break;
                    }
                    return wx.setStorageSync("accessToken", p.data.token), e.next = 24, (0, u.getDatas)();

                  case 24:
                    setTimeout(function() {
                        wx.switchTab({
                            url: "/pages/home/home"
                        });
                    }, 100);

                  case 25:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    phoneChange: function(e) {
        this.setData({
            phone: e.detail.value
        });
    },
    checkedTap: function() {
        this.setData({
            agree: !this.data.agree
        });
    },
    securityCodeChange: function(e) {
        this.setData({
            securityCode: e.detail.value
        });
    },
    accountChange: function(e) {
        this.setData({
            account: e.detail.value
        });
    },
    passwordChange: function(e) {
        this.setData({
            password: e.detail.value
        });
    },
    sendCode: function(e) {
        var a = this;
        return n(t.default.mark(function e() {
            var n, o;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (a.data.phone) {
                        e.next = 3;
                        break;
                    }
                    return wx.showToast({
                        title: "请输入手机号码",
                        icon: "error",
                        duration: 2e3
                    }), e.abrupt("return");

                  case 3:
                    if (new RegExp(/^(13[0-9]|14[01456879]|15[0-35-9]|16[2567]|17[0-8]|18[0-9]|19[0-35-9])\d{8}$/).test(a.data.phone)) {
                        e.next = 8;
                        break;
                    }
                    return wx.showToast({
                        title: "手机号码不正确",
                        icon: "error",
                        duration: 2e3
                    }), e.abrupt("return");

                  case 8:
                    if (a.data.agree) {
                        e.next = 11;
                        break;
                    }
                    return wx.showToast({
                        title: "请阅读并勾选协议",
                        icon: "error"
                    }), e.abrupt("return");

                  case 11:
                    return a.setData({
                        hasSendCode: !0
                    }), n = new Date().getTime() + 6e4, wx.setStorageSync("codeCountDownTime", new String(n)), 
                    a.setSendCodeTimeOut(), e.next = 17, r.Http.request({
                        noMsg: !0,
                        url: "/api/login/sendSecurityCode",
                        data: {
                            phone: a.data.phone,
                            channelId: s.default.channelId
                        }
                    });

                  case 17:
                    (o = e.sent).success || (a.setData({
                        hasSendCode: !1,
                        timeOut: 60
                    }), wx.removeStorageSync("codeCountDownTime"), wx.showModal({
                        title: "提示",
                        content: o.message,
                        showCancel: !1,
                        success: function(e) {
                            e.confirm ? console.log("用户点击确定") : e.cancel && console.log("用户点击取消");
                        }
                    }));

                  case 19:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    },
    initCountDown: function() {
        var e = wx.getStorageSync("codeCountDownTime"), t = new Date().getTime();
        if (e && parseInt(e) > t) {
            var n = ((e = parseInt(e)) - t) / 1e3;
            return this.setData({
                hasSendCode: !0,
                timeOut: parseInt(n)
            }), this.setSendCodeTimeOut(), !1;
        }
        return !0;
    },
    setSendCodeTimeOut: function() {
        var e = this;
        if (+this.data.timeOut <= 0) return this.setData({
            hasSendCode: !1,
            timeOut: 60
        }), void wx.removeStorageSync("codeCountDownTime");
        i = setTimeout(function() {
            clearTimeout(i), e.setData({
                timeOut: e.data.timeOut - 1
            }, function() {
                return e.setSendCodeTimeOut();
            });
        }, 1e3);
    },
    gotoHome: function() {
        setTimeout(function() {
            wx.redirectTo({
                url: "/pages/tickets/tickets"
            });
        }, 100);
    },
    goRealNameAuth: function(e, t) {
        var n = this, a = (t || {}).isNew;
        c.globalData.isNew = Number(a), c.globalData.loginPhone = null, setTimeout(function() {
            var t = "/pages/identity/identity?isNew=".concat(Number(a));
            e && (c.globalData.loginPhone = n.data.phone, t = "/pages/identity/identity?phone=".concat(n.data.phone, "&isNew=").concat(Number(a))), 
            wx.redirectTo({
                url: t
            });
        }, 100);
    },
    prod: function() {
        s.default.init("prod"), wx.setStorageSync("env", "prod"), this.setData({
            tabVal: 1,
            showButtons: !1
        }), wx.showModal({
            title: "提示",
            content: "当前环境已切换生产环境",
            showCancel: !1,
            success: function(e) {}
        });
    },
    uat: function() {
        s.default.init("uat"), wx.setStorageSync("env", "uat"), this.setData({
            tabVal: 1,
            showButtons: !0
        }), wx.showModal({
            title: "提示",
            content: "当前环境已切换 uat 环境",
            showCancel: !1,
            success: function(e) {}
        });
    },
    sit: function() {
        s.default.init("sit"), wx.setStorageSync("env", "sit"), this.setData({
            tabVal: 1,
            showButtons: !0
        }), wx.showModal({
            title: "提示",
            content: "当前环境已切换 sit 环境",
            showCancel: !1,
            success: function(e) {}
        });
    },
    daily: function() {
        this.setData({
            tabVal: 1,
            showButtons: !0
        }), s.default.init("daily"), wx.setStorageSync("env", "daily"), wx.showModal({
            title: "提示",
            content: "当前环境已切换 daily",
            showCancel: !1,
            success: function(e) {}
        });
    },
    onShareAppMessage: function(e) {},
    groupType1TextClick: function() {
        this.setData({
            groupType: "2"
        }), this.getPhone();
    },
    groupType2TextClick: function() {
        this.setData({
            groupType: "1"
        });
    },
    groupAccountChange: function(e) {
        var t = this;
        clearTimeout(this.time), this.setData({
            account: e.detail.value
        }), this.time = setTimeout(function() {
            clearTimeout(t.time), t.getPhone();
        }, 1e3);
    },
    getPhone: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var a;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.data.account) {
                        t.next = 2;
                        break;
                    }
                    return t.abrupt("return");

                  case 2:
                    return console.log("Hello World!"), t.next = 5, r.Http.request({
                        noMsg: !0,
                        url: "/api/login/custInfo",
                        data: {
                            type: "2",
                            idNo: e.data.account,
                            channelId: s.default.channelId
                        }
                    });

                  case 5:
                    (a = t.sent).success && e.setData({
                        phone: a.data
                    });

                  case 7:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    groupSendCode: function() {
        var e = this;
        return n(t.default.mark(function n() {
            var a, o, s;
            return t.default.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                  case 0:
                    if (e.data.phone) {
                        t.next = 3;
                        break;
                    }
                    return wx.showToast({
                        title: "请输入手机号码",
                        icon: "error",
                        duration: 2e3
                    }), t.abrupt("return");

                  case 3:
                    if (e.data.account) {
                        t.next = 6;
                        break;
                    }
                    return wx.showToast({
                        title: "请输入账号",
                        icon: "error",
                        duration: 2e3
                    }), t.abrupt("return");

                  case 6:
                    if (e.data.agree) {
                        t.next = 9;
                        break;
                    }
                    return wx.showToast({
                        title: "请阅读并勾选协议",
                        icon: "error"
                    }), t.abrupt("return");

                  case 9:
                    return e.setData({
                        hasSendCode: !0
                    }), a = new Date().getTime() + 6e4, wx.setStorageSync("codeCountDownTime", new String(a)), 
                    e.setSendCodeTimeOut(), t.next = 15, (0, u.getChannelId)();

                  case 15:
                    return o = t.sent, t.next = 18, r.Http.request({
                        noMsg: !0,
                        url: "/api/login/sendTuanSecurityCode",
                        data: {
                            idNo: e.data.account,
                            channelId: o
                        }
                    });

                  case 18:
                    (s = t.sent).success || (e.setData({
                        hasSendCode: !1,
                        timeOut: 60
                    }), wx.removeStorageSync("codeCountDownTime"), wx.showModal({
                        title: "提示",
                        content: s.message,
                        showCancel: !1,
                        success: function(e) {
                            e.confirm ? console.log("用户点击确定") : e.cancel && console.log("用户点击取消");
                        }
                    }));

                  case 20:
                  case "end":
                    return t.stop();
                }
            }, n);
        }))();
    },
    groupLogin2: function(e) {
        var a = this;
        return n(t.default.mark(function e() {
            var n, i, c, d, l, h;
            return t.default.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                  case 0:
                    if (n = a.data, i = n.account, n.password, a.data.agree) {
                        e.next = 4;
                        break;
                    }
                    return wx.showToast({
                        title: "请阅读并勾选协议",
                        icon: "error"
                    }), e.abrupt("return");

                  case 4:
                    if (i) {
                        e.next = 7;
                        break;
                    }
                    return wx.showToast({
                        title: "请输入账号",
                        icon: "error",
                        duration: 2e3
                    }), e.abrupt("return");

                  case 7:
                    return e.next = 9, (0, u.getChannelId)();

                  case 9:
                    return c = e.sent, e.next = 12, o.Wx.wxLogin();

                  case 12:
                    return d = e.sent, l = {
                        type: 2,
                        idNo: i,
                        securityCode: a.data.securityCode,
                        channelId: c,
                        code: d.code,
                        appId: s.default.appId
                    }, e.next = 16, r.Http.request({
                        url: "/api/login/cardPwd",
                        data: l
                    });

                  case 16:
                    if (!(h = e.sent).success) {
                        e.next = 22;
                        break;
                    }
                    return wx.setStorageSync("accessToken", h.data.token), e.next = 21, (0, u.getDatas)();

                  case 21:
                    setTimeout(function() {
                        wx.switchTab({
                            url: "/pages/home/home"
                        });
                    }, 100);

                  case 22:
                  case "end":
                    return e.stop();
                }
            }, e);
        }))();
    }
});