var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../utils/util"));

Page({
    data: {
        url: ""
    },
    onLoad: function(e) {
        wx.showLoading({
            title: "加载中"
        });
    },
    onShow: function() {
        this.setData({
            url: ""
        });
        var t = e.default.buildUrl("integral", "", !0);
        this.setData({
            url: t
        });
    },
    onLoadCompelete: function() {
        wx.hideLoading();
    },
    onShareAppMessage: function(e) {}
});