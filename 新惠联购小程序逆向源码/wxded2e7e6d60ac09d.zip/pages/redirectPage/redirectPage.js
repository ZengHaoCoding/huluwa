Page({
    data: {
        url: "",
        link: "",
        isReset: !1
    },
    onLoad: function(o) {
        console.log("url---", decodeURIComponent(o.url)), this.setData({
            url: decodeURIComponent(o.url)
        });
    },
    onLoadFinish: function() {
        wx.hideLoading();
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    webViewMessage: function(o) {
        console.log("------aaaaa------"), util.getMsg(o, function(o) {
            if (console.log(o), "share" === o.action) {
                var n = o.shareData;
                n.shareUrl, n.shareTitle, n.shareDesc;
            }
        });
    },
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function(o) {
        console.log(o), console.log("tttttt");
    }
});