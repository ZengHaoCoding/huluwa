Page({
    data: {
        orderId: "",
        topTitle: ""
    },
    onLoad: function(e) {
        wx.hideHomeButton({}), this.setData({
            orderId: e.orderId
        });
        var t = "支付失败！";
        e.topTitle && "undefined" !== e.topTitle && (t = decodeURIComponent(e.topTitle));
        var o = {
            orderId: e.orderId,
            topTitle: t
        };
        this.setData(o);
    },
    go: function() {
        wx.reLaunch({
            url: "/pages/orderDetail/orderDetail?orderId=".concat(this.data.orderId)
        });
    },
    goIndex: function() {
        wx.switchTab({
            url: "/pages/home/home"
        });
    }
});