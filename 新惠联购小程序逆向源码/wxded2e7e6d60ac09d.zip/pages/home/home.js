var e = require("../../@babel/runtime/helpers/interopRequireDefault"), t = e(require("../../utils/util")), i = e(require("../../utils/config"));

Page({
    data: {
        url: ""
    },
    onShow: function() {
        var e = this, a = this.time = setInterval(function() {
            if (i.default.isGetDatas) {
                clearInterval(a);
                var l = t.default.buildUrl("home");
                console.log(l), e.setData({
                    url: l
                });
            }
        }, 200);
    },
    onUnload: function() {
        clearInterval(this.time);
    },
    onLoadCompelete: function() {
        console.log("----"), wx.setNavigationBarTitle({
            title: "首页"
        });
    },
    onShareAppMessage: function(e) {}
});