var e = require("../../utils/otherUtil");

Page({
    data: {
        orderId: "",
        topTitle: "",
        title: "",
        subtitle: "",
        type: 1
    },
    onLoad: function(e) {
        wx.hideHomeButton({});
        var t = "支付成功！";
        e.topTitle && "undefined" !== e.topTitle && (t = decodeURIComponent(e.topTitle));
        var o = {
            orderId: e.orderId,
            title: decodeURIComponent(e.title),
            subtitle: decodeURIComponent(e.subtitle),
            topTitle: t
        };
        e.type && (o.type = parseInt(e.type)), this.setData(o);
    },
    go: function() {
        var t = (0, e.parseParams)({
            orderId: this.data.orderId
        });
        wx.reLaunch({
            url: "/pages/orderDetail/orderDetail?".concat(t)
        });
    },
    goIndex: function() {
        wx.switchTab({
            url: "/pages/home/home"
        });
    }
});