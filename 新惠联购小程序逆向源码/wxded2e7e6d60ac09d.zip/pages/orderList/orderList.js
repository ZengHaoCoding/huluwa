var e = require("../../@babel/runtime/helpers/interopRequireDefault")(require("../../utils/util"));

Page({
    data: {},
    onLoad: function(t) {
        wx.hideHomeButton({});
        var r = e.default.buildUrl("orderList");
        this.setData({
            url: r
        });
    },
    onShareAppMessage: function(e) {}
});