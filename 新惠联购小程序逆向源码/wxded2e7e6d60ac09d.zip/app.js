var e, n = require("@babel/runtime/helpers/interopRequireDefault"), t = n(require("@babel/runtime/regenerator")), o = require("@babel/runtime/helpers/asyncToGenerator"), a = n(require("./utils/config")), r = require("./utils/common");

App({
    onLaunch: (e = o(t.default.mark(function e() {
        var n, o, i;
        return t.default.wrap(function(e) {
            for (;;) switch (e.prev = e.next) {
              case 0:
                return this.autoUpdate(), o = wx.getAccountInfoSync(), "release" != (i = null == o || null === (n = o.miniProgram) || void 0 === n ? void 0 : n.envVersion) && (i = wx.getStorageSync("env") || "uat"), 
                console.log(i), a.default.init(i), e.next = 8, (0, r.getDatas)();

              case 8:
              case "end":
                return e.stop();
            }
        }, e, this);
    })), function() {
        return e.apply(this, arguments);
    }),
    autoUpdate: function() {
        var e = this;
        if (wx.canIUse("getUpdateManager")) {
            var n = wx.getUpdateManager();
            n.onCheckForUpdate(function(t) {
                t.hasUpdate && wx.showModal({
                    title: "更新提示",
                    content: "检测到新版本，是否下载新版本并重启小程序？",
                    success: function(t) {
                        t.confirm ? e.downLoadAndUpdate(n) : t.cancel && wx.showModal({
                            title: "温馨提示",
                            content: "本次版本更新涉及到新的功能添加，旧版本无法正常访问的哦",
                            showCancel: !1,
                            confirmText: "确定更新",
                            success: function(t) {
                                t.confirm && e.downLoadAndUpdate(n);
                            }
                        });
                    }
                });
            });
        } else wx.showModal({
            title: "提示",
            content: "当前微信版本过低，无法使用该功能，请升级到最新微信版本后重试。"
        });
    },
    downLoadAndUpdate: function(e) {
        wx.showLoading(), e.onUpdateReady(function() {
            console.log("静默下载更新小程序新版本"), wx.hideLoading(), e.applyUpdate();
        }), e.onUpdateFailed(function() {
            console.log("新的版本下载失败"), wx.hideLoading(), wx.showModal({
                title: "已经有新版本了哟~",
                content: "新版本已经上线啦~，请您删除当前小程序，重新搜索打开哟~"
            });
        });
    },
    globalData: {
        wxUserInfo: null,
        wxPhoneNumberInfo: null,
        userInfo: null,
        isNew: null,
        loginPhone: null
    }
});